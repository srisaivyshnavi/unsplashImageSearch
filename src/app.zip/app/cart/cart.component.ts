import { Component, OnInit } from '@angular/core';
import { Store, select } from "@ngrx/store";
import { Observable } from "rxjs/Observable";
import * as Cart from "./../store/actions";

@Component({
  selector: 'app-cart',
  template:
    `
<button  [routerLink]="['/products']" class="btn btn-info">Back to home</button>
<div *ngFor="let obj of lists;let i = index">
<input type="text" ngModel = "{{obj.name}}" value="{{obj.name}}" [disabled] = "flag">
<button *ngIf = "editbtn" (click)="edit(i)" class="btn-info">Edit</button>
<button *ngIf = "saveBtn" (click)="save(i,obj.value)" class="btn-info">Save</button>
<div *ngFor="let obj1 of obj.value" >
    <img src="{{obj1}}" (click)="downloadFav(obj1)" class="size">
</div>
</div>
  `,
  styles: [`
.size{
width:200px;
height:200px;
margin-bottom:10px
  }`]
})
export class CartComponent implements OnInit {

  cart: Observable<Array<any>>
  lists: any;
  finalList: any[];
  editbtn:boolean = true;
  saveBtn : boolean = false;
  flag:boolean = true;
  constructor(private store: Store<any>) {
    
    this.store.select('cart').subscribe(data => {
      this.lists = data;
    var op = {};
      var uniqNames = [...new Set(data.map(item => item.name))]
      console.log(uniqNames)
      uniqNames.forEach((uName: string)=> {
        data.map(item => {
          if (item.name === uName) {
            if (!op[uName]) op[uName] = [];
            op[uName].push(item.value)
          }
        })
        console.log("----------------------", op);
        var newOp = Object.keys(op).map(item => {
          return {
            name: item,
            value: op[item].map(opItem => opItem)
          }
        }
        );

        console.log("-----------------", newOp);
        this.lists = newOp;
      });
      
      
    })
  }


  downloadFav(obj) {
    this.toDataURL(obj.urls.small, function (dataUrl) {
      console.log(dataUrl)
      var a = document.createElement("a"); //Create <a>
      a.href = dataUrl; //Image Base64 Goes here
      a.download = "Image.png"; //File name Here
      a.click();
    })
  }
  toDataURL(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
      var reader = new FileReader();
      reader.onloadend = function () {
        callback(reader.result);
      }
      reader.readAsDataURL(xhr.response);
    };
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.send();
  }

edit(i){
  console.log(i)
this.flag = false;
this.editbtn = false;
this.saveBtn = true;
  }
save(i,name){
  console.log(i,name)
this.flag= true;
this.editbtn = true;
this.saveBtn = false;
  }


  ngOnInit() {

    
  }
      

}
