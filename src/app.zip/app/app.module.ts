import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { CartComponent } from './cart/cart.component';
import { ProductComponent } from './product/product.component';
import { Routes, RouterModule } from '@angular/router';
import {SearchServiceService} from './search-service.service';
import{HttpClientModule} from '@angular/common/http'
import { MaterialModule } from './material/material.module';

import { StoreModule } from "@ngrx/store";
import { reducer } from './store/reducer';
 import { AddFavouriteComponent } from './add-favourite/add-favourite.component';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
const routes: Routes = [
    {
        path: '',
        redirectTo: '/products',
        pathMatch: 'full'
    },
    {
        path: 'products',
        component: ProductsComponent
    },
    {
        path: 'cart',
        component: CartComponent
    },
    {
        path: 'product/:id',
        component: ProductComponent
    },
    {
        path: '**',
        redirectTo: '',
        pathMatch: 'full'
    }
];

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    CartComponent,
    ProductComponent,
    AddFavouriteComponent 
  ],
  imports: [
    BrowserModule,
    MaterialModule,
    FormsModule,
    RouterModule.forRoot(routes),
    StoreModule.forRoot({cart: reducer}),
    HttpClientModule,
    BrowserAnimationsModule
  ],
  entryComponents:[AddFavouriteComponent],
  providers: [SearchServiceService], 
  bootstrap: [AppComponent]
})
export class AppModule { }
