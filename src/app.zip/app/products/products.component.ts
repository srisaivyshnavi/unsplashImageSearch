import { Component, OnInit } from '@angular/core';
import { PRODUCTS } from "./../store/market";
import { SearchServiceService } from '../search-service.service';
import { AddFavouriteComponent } from '../add-favourite/add-favourite.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ["./products.component.scss"]
})
export class ProductsComponent implements OnInit {

  products = PRODUCTS
  response: any;

  constructor(private service: SearchServiceService, private dialog: MatDialog) { }
  
  ngOnInit() {}
  search(query) {
    this.service.getSearchResult(query).subscribe(result => {
      console.log(result);
      this.response = result["results"]
    })
  }
  authorPage(image) {
    window.open(image.links.download);
  }
  addSelected(i, product) {
    const dialogRef = this.dialog.open(AddFavouriteComponent, {
      width: '500px',
      height: '200px',
      data: product
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result)
    });
  }

}
